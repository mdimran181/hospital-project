   <!-- footer section --> 
			<footer>
				<div class="col-md-12 fsection">
					<div class="col-md-4" id="contact">
					<p>Category</p>
					<ul>
						<li><a href="#">Sign Up as a Donor</a></li>
						<li><a href="#">Contact with Doctors</a></li>
						
					</ul>
					</div>
					<div class="col-md-4">
						<p>Contact with us</p>
						<p>Md Emran <br>
							cell:01838235450</p>
						
					</div>
					<div class="col-md-4 share_img">
					<p>Link with</p>
						<a href=""><img src="img/fb-free.png" alt="facebook"></a>
						<a href=""><img src="img/gogle-plud-free.png" alt="google"></a>
						<a href=""><img src="img/twiter.png" alt="twitter"></a>
					</div>
				</div>
				

			</footer>

		<!-- footer section Ends--> 
