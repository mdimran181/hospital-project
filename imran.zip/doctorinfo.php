<?php include('header.php'); ?>


	<!-- mc info -->
	<div class="doctors">
        
		                    <h3 class="text-center" style="background-color:#231256;color: #fff;">Doctor Near your Hands</h3>
                            <div class="col-md-12" style="">
                                  


                                  <div class="col-md-3">
                                      <img src="img/doctor01.jpg" alt="" class="img-responsive" style="width: 220px;height: 220px">
                                  </div> <br>

                                  <div class="col-md-3" > 

                                     
                                     <h3 style="color:#0616BC;">Dr. Md Emran</h3>


                                        <!-- Accordian Starts -->
                                            <div class="panel-group" id="accordion" role="tablist" aria-multiselectable="true">
                                              <div class="panel panel-default">
                                                <div class="panel-heading" role="tab" id="headingOne">
                                                  <h4 class="panel-title">
                                                    <a role="button" data-toggle="collapse" data-parent="#accordion" href="#collapseOne" aria-expanded="true" aria-controls="collapseOne">
                                                      Qualifications
                                                    </a>
                                                  </h4>
                                                </div>
                                                <div id="collapseOne" class="panel-collapse collapse in" role="tabpanel" aria-labelledby="headingOne">
                                                  <div class="panel-body">
                                                        MBBS, BCS (Health), MS (Neorology &amp; Medicine)Neorology &amp; Medicine Specialist
                                                  </div>
                                                </div>
                                              </div>
                                              <div class="panel panel-default">
                                                <div class="panel-heading" role="tab" id="headingTwo">
                                                  <h4 class="panel-title">
                                                    <a class="collapsed" role="button" data-toggle="collapse" data-parent="#accordion" href="#collapseTwo" aria-expanded="false" aria-controls="collapseTwo">
                                                      Chamber
                                                    </a>
                                                  </h4>
                                                </div>
                                                <div id="collapseTwo" class="panel-collapse collapse" role="tabpanel" aria-labelledby="headingTwo">
                                                  <div class="panel-body">
                                                        Chamber: Ibn Sina Hospital,Dhanmondi, Dhaka
                                                       
                                                  </div>
                                                </div>
                                              </div>
                                              <div class="panel panel-default">
                                                <div class="panel-heading" role="tab" id="headingThree">
                                                  <h4 class="panel-title">
                                                    <a class="collapsed" role="button" data-toggle="collapse" data-parent="#accordion" href="#collapseThree" aria-expanded="false" aria-controls="collapseThree">
                                                      Call for Appoinment 
                                                    </a>
                                                  </h4>
                                                </div>
                                                <div id="collapseThree" class="panel-collapse collapse" role="tabpanel" aria-labelledby="headingThree">
                                                  <div class="panel-body">
                                                     Phone:+8801838235450
                                                  </div>
                                                </div>
                                              </div>

                                              <div class="panel panel-default">
                                                <div class="panel-heading" role="tab" id="headingOne">
                                                  <h4 class="panel-title">
                                                    <a href="patient_login.php">
                                                      Touch Appoinment
                                                    </a>
                                                  </h4>
                                                </div>
                                                
                                              </div>

                                            </div>


                                            <!-- Accordian End -->
                                        


                                  </div>

                                 <div class="col-md-3">
                                      <img src="img/doctor2.jpg" alt="" class="img-responsive" style="width: 220px;height: 220px"> <br>
                                  </div>

                                  <div class="col-md-3">
                                       
                                       <h3 style="color:#0616BC;">Dr. Ayesha Akter Banu</h3>

                                             <!-- Accordian Start -->

                                            <div class="panel-group" id="accordion" role="tablist" aria-multiselectable="true">
                                              <div class="panel panel-default">
                                                <div class="panel-heading" role="tab" id="headingOne1">
                                                  <h4 class="panel-title">
                                                    <a role="button" data-toggle="collapse" data-parent="#accordion" href="#collapseOne1" aria-expanded="true" aria-controls="collapseOne1">
                                                      Qualifications
                                                    </a>
                                                  </h4>
                                                </div>
                                                <div id="collapseOne1" class="panel-collapse collapse in" role="tabpanel" aria-labelledby="headingOne1">
                                                  <div class="panel-body">
                                                        MBBS, MCPS 
                                                        Senior Consultant Gynecologist & Obestetrics
                                                  </div>
                                                </div>
                                              </div>
                                              <div class="panel panel-default">
                                                <div class="panel-heading" role="tab" id="headingTwo2">
                                                  <h4 class="panel-title">
                                                    <a class="collapsed" role="button" data-toggle="collapse" data-parent="#accordion" href="#collapseTwo2" aria-expanded="false" aria-controls="collapseTwo2">
                                                      Chamber
                                                    </a>
                                                  </h4>
                                                </div>
                                                <div id="collapseTwo2" class="panel-collapse collapse" role="tabpanel" aria-labelledby="headingTwo2">
                                                  <div class="panel-body">
                                                         Dhaka Medical College,Dhaka
                                                       
                                                  </div>
                                                </div>
                                              </div>
                                              <div class="panel panel-default">
                                                <div class="panel-heading" role="tab" id="headingThree3">
                                                  <h4 class="panel-title">
                                                    <a class="collapsed" role="button" data-toggle="collapse" data-parent="#accordion" href="#collapseThree3" aria-expanded="false" aria-controls="collapseThree3">
                                                      Call For Appointment
                                                    </a>
                                                  </h4>
                                                </div>
                                                <div id="collapseThree3" class="panel-collapse collapse" role="tabpanel" aria-labelledby="headingThree3">
                                                  <div class="panel-body">
                                                     Phone: +8801838235450
                                                  </div>
                                                </div>
                                              </div>

                                              <div class="panel panel-default">
                                                <div class="panel-heading" role="tab" id="headingOne">
                                                  <h4 class="panel-title">
                                                    <a href="patient_login.php">
                                                      Touch Appoinment
                                                    </a>
                                                  </h4>
                                                </div>
                                                
                                              </div>

                                            </div>
                                        
                                          <!-- Accordian End -->  
                                            
                                   </div> 
                             </div> <!-- col-md-12 End-->

                            <br><br>


                             <div class="col-md-12" style="">
                                  


                                  <div class="col-md-3">
                                      <img src="img/doctor5.jpg" alt="" class="img-responsive" style="width: 220px;height: 220px">
                                  </div>

                                  <div class="col-md-3" > 

                                     
                                     <h3 style="color:#0616BC;">Dr.Habibur Rahaman</h3>


                                        <!-- Accordian Starts -->
                                            <div class="panel-group" id="accordion" role="tablist" aria-multiselectable="true">
                                              <div class="panel panel-default">
                                                <div class="panel-heading" role="tab" id="headingOne">
                                                  <h4 class="panel-title">
                                                    <a role="button" data-toggle="collapse" data-parent="#accordion" href="#collapseOne11" aria-expanded="true" aria-controls="collapseOne11">
                                                      Qualifications
                                                    </a>
                                                  </h4>
                                                </div>
                                                <div id="collapseOne11" class="panel-collapse collapse in" role="tabpanel" aria-labelledby="headingOne">
                                                  <div class="panel-body">
                                                      MBBS, FCPS(Medicine), MD(Nephrology)
                                                      Consultant Nephrology & Medicine Specialist
                                                  </div>
                                                </div>
                                              </div>
                                              <div class="panel panel-default">
                                                <div class="panel-heading" role="tab" id="headingTwo">
                                                  <h4 class="panel-title">
                                                    <a class="collapsed" role="button" data-toggle="collapse" data-parent="#accordion" href="#collapseTwo22" aria-expanded="false" aria-controls="collapseTwo22">
                                                      Chamber
                                                    </a>
                                                  </h4>
                                                </div>
                                                <div id="collapseTwo22" class="panel-collapse collapse" role="tabpanel" aria-labelledby="headingTwo">
                                                  <div class="panel-body">
                                                       Monowara Hospital (pvt) Ltd 
                                                       54, Siddeshwari Road, Dhaka- 1217
                                                       
                                                  </div>
                                                </div>
                                              </div>
                                              <div class="panel panel-default">
                                                <div class="panel-heading" role="tab" id="headingThree">
                                                  <h4 class="panel-title">
                                                    <a class="collapsed" role="button" data-toggle="collapse" data-parent="#accordion" href="#collapseThree33" aria-expanded="false" aria-controls="collapseThree33">
                                                     Call for Appointment
                                                    </a>
                                                  </h4>
                                                </div>
                                                <div id="collapseThree33" class="panel-collapse collapse" role="tabpanel" aria-labelledby="headingThree">
                                                  <div class="panel-body">
                                                    Phone: +8801817517100
                                                  </div>
                                                </div>
                                              </div>

                                              <div class="panel panel-default">
                                                <div class="panel-heading" role="tab" id="headingOne">
                                                  <h4 class="panel-title">
                                                    <a href="patient_login.php">
                                                      Touch Appoinment
                                                    </a>
                                                  </h4>
                                                </div>
                                                
                                              </div>


                                            </div>


                                            <!-- Accordian End -->
                                        


                                  </div>

                                 <div class="col-md-3">
                                      <img src="img/d1.jpg" alt="" class="img-responsive" style="width: 220px;height: 220px">
                                  </div>

                                  <div class="col-md-3">
                                       
                                       <h3 style="color:#0616BC;">Professor Dr. Md. Johurul Haque</h3>

                                             <!-- Accordian Start -->

                                            <div class="panel-group" id="accordion" role="tablist" aria-multiselectable="true">
                                              <div class="panel panel-default">
                                                <div class="panel-heading" role="tab" id="headingOne">
                                                  <h4 class="panel-title">
                                                    <a role="button" data-toggle="collapse" data-parent="#accordion" href="#collapseOne111" aria-expanded="true" aria-controls="collapseOne111">
                                                      Qualifications
                                                    </a>
                                                  </h4>
                                                </div>
                                                <div id="collapseOne111" class="panel-collapse collapse in" role="tabpanel" aria-labelledby="headingOne">
                                                  <div class="panel-body">
                                                        MBBS, MPhil, FWHO(India), BCS
                                                  </div>
                                                </div>
                                              </div>
                                              <div class="panel panel-default">
                                                <div class="panel-heading" role="tab" id="headingTwo">
                                                  <h4 class="panel-title">
                                                    <a class="collapsed" role="button" data-toggle="collapse" data-parent="#accordion" href="#collapseTwo222" aria-expanded="false" aria-controls="collapseTwo222">
                                                      Chamber
                                                    </a>
                                                  </h4>
                                                </div>
                                                <div id="collapseTwo222" class="panel-collapse collapse" role="tabpanel" aria-labelledby="headingTwo">
                                                  <div class="panel-body">
                                                       Ibn Sina Diagnostic & Imaging Center
                                                       
                                                  </div>
                                                </div>
                                              </div>
                                              <div class="panel panel-default">
                                                <div class="panel-heading" role="tab" id="headingThree">
                                                  <h4 class="panel-title">
                                                    <a class="collapsed" role="button" data-toggle="collapse" data-parent="#accordion" href="#collapseThree333" aria-expanded="false" aria-controls="collapseThree333">
                                                      Call For Appointment 
                                                    </a>
                                                  </h4>
                                                </div>
                                                <div id="collapseThree333" class="panel-collapse collapse" role="tabpanel" aria-labelledby="headingThree">
                                                  <div class="panel-body">
                                                     Phone: +8801764197461
                                                  </div>
                                                </div>
                                              </div>

                                              <div class="panel panel-default">
                                                <div class="panel-heading" role="tab" id="headingOne">
                                                  <h4 class="panel-title">
                                                    <a href="patient_login.php">
                                                      Touch Appoinment
                                                    </a>
                                                  </h4>
                                                </div>
                                                
                                              </div>
                                              
                                            </div>
                                        
                                          <!-- Accordian End -->  
                                          </div>

                                 



                                    <div class="col-md-12" style="">
                                  


                                  <div class="col-md-3">
                                      <img src="img/doctor01.jpg" alt="" class="img-responsive" style="width: 220px;height: 220px">
                                  </div> <br>

                                  <div class="col-md-3" > 

                                     
                                     <h3 style="color:#0616BC;">Dr. Ahmed Khan</h3>


                                        <!-- Accordian Starts -->
                                            <div class="panel-group" id="accordion" role="tablist" aria-multiselectable="true">
                                              <div class="panel panel-default">
                                                <div class="panel-heading" role="tab" id="headingOne">
                                                  <h4 class="panel-title">
                                                    <a role="button" data-toggle="collapse" data-parent="#accordion" href="#collapseOne111" aria-expanded="true" aria-controls="collapseOne111">
                                                      Qualifications
                                                    </a>
                                                  </h4>
                                                </div>
                                                <div id="collapseOne" class="panel-collapse collapse in" role="tabpanel" aria-labelledby="headingOne111">
                                                  <div class="panel-body">
                                                        MBBS, BCS , MS,FCPS (Neorology &amp; Medicine)Neorology &amp; Medicine Specialist
                                                  </div>
                                                </div>
                                              </div>
                                              <div class="panel panel-default">
                                                <div class="panel-heading" role="tab" id="headingTwo">
                                                  <h4 class="panel-title">
                                                    <a class="collapsed" role="button" data-toggle="collapse" data-parent="#accordion" href="#collapseTwo111" aria-expanded="false" aria-controls="collapseTwo111">
                                                      Chamber
                                                    </a>
                                                  </h4>
                                                </div>
                                                <div id="collapseTwo" class="panel-collapse collapse" role="tabpanel" aria-labelledby="headingTwo111">
                                                  <div class="panel-body">
                                                        Chamber: Ibn Sina Hospital,Dhanmondi, Dhaka
                                                       
                                                  </div>
                                                </div>
                                              </div>
                                              <div class="panel panel-default">
                                                <div class="panel-heading" role="tab" id="headingThree">
                                                  <h4 class="panel-title">
                                                    <a class="collapsed" role="button" data-toggle="collapse" data-parent="#accordion" href="#collapseThree111" aria-expanded="false" aria-controls="collapseThree111">
                                                      Call for Appoinment 
                                                    </a>
                                                  </h4>
                                                </div>
                                                <div id="collapseThree111" class="panel-collapse collapse" role="tabpanel" aria-labelledby="headingThree">
                                                  <div class="panel-body">
                                                     Phone:+8801838235450
                                                  </div>
                                                </div>
                                              </div>

                                              <div class="panel panel-default">
                                                <div class="panel-heading" role="tab" id="headingOne111">
                                                  <h4 class="panel-title">
                                                    <a href="patient_login.php">
                                                      Touch Appoinment
                                                    </a>
                                                  </h4>
                                                </div>
                                                
                                              </div>

                                            </div>


                                            <!-- Accordian End -->
                                        


                                  </div>
                                   <div class="col-md-3">
                                      <img src="img/d2.jpg" alt="" class="img-responsive" style="width: 220px;height: 220px">
                                  </div> <br>

                                  <div class="col-md-3" > 

                                     
                                     <h3 style="color:#0616BC;">Dr. Afsana Khanom</h3>


                                        <!-- Accordian Starts -->
                                            <div class="panel-group" id="accordion" role="tablist" aria-multiselectable="true">
                                              <div class="panel panel-default">
                                                <div class="panel-heading" role="tab" id="headingOne222">
                                                  <h4 class="panel-title">
                                                    <a role="button" data-toggle="collapse" data-parent="#accordion" href="#collapseOne222" aria-expanded="true" aria-controls="collapseOne222">
                                                      Qualifications
                                                    </a>
                                                  </h4>
                                                </div>
                                                <div id="collapseOne" class="panel-collapse collapse in" role="tabpanel" aria-labelledby="headingOne111">
                                                  <div class="panel-body">
                                                        MBBS, FCPS, MS (Oncology &amp; Medicine)Neorology &amp; 
                                                  </div>
                                                </div>
                                              </div>
                                              <div class="panel panel-default">
                                                <div class="panel-heading" role="tab" id="headingTwo2222">
                                                  <h4 class="panel-title">
                                                    <a class="collapsed" role="button" data-toggle="collapse" data-parent="#accordion" href="#collapseTwo2222" aria-expanded="false" aria-controls="collapseTwo2222">
                                                      Chamber
                                                    </a>
                                                  </h4>
                                                </div>
                                                <div id="collapseTwo222" class="panel-collapse collapse" role="tabpanel" aria-labelledby="headingTwo222">
                                                  <div class="panel-body">
                                                        Chamber: Lab Aid Hospital,Dhanmondi, Dhaka
                                                       
                                                  </div>
                                                </div>
                                              </div>
                                              <div class="panel panel-default">
                                                <div class="panel-heading" role="tab" id="headingThree222">
                                                  <h4 class="panel-title">
                                                    <a class="collapsed" role="button" data-toggle="collapse" data-parent="#accordion" href="#collapseThree222" aria-expanded="false" aria-controls="collapseThree222">
                                                      Call for Appoinment 
                                                    </a>
                                                  </h4>
                                                </div>
                                                <div id="collapseThree222" class="panel-collapse collapse" role="tabpanel" aria-labelledby="headingThree222">
                                                  <div class="panel-body">
                                                     Phone:+8801838232211
                                                  </div>
                                                </div>
                                              </div>

                                              <div class="panel panel-default">
                                                <div class="panel-heading" role="tab" id="headingOne222">
                                                  <h4 class="panel-title">
                                                    <a href="patient_login.php">
                                                      Touch Appoinment
                                                    </a>
                                                  </h4>
                                                </div>
                                                
                                              </div>

                                            </div>


                                            <!-- Accordian End -->
                                        


                                  </div>
                                 


                                            
                           <!-- col-md-12 End-->





                              

                            <br><br>


                             




	</div> <!-- Doctors End -->

    <!-- footer section  is here--> 
			 <?php include('footer.php'); ?>
    <!-- footer section Ends--> 
	



		
	</div><!--  containerFluid Ends -->


               <script src="js/jquery-1.11.3.min.js"></script> <!-- this works for collapse -->
                <script src="js/bootstrap.min.js"></script>
	
</body>
</html>






