<?php include('header.php'); ?>





	<!-- this is for donor registraton -->
	<div class="main_content" style="background-color:#fff;">
		<h3 class="text-center" style="background-color:#272327;color: #fff;">About Us</h3>
		<div class="col-md-12">
			<div class="col-md-6">
				<img src="img/aboutimag33.jpg" alt="" class="img-responsive">
			</div>

			<div class="col-md-6">
				<article>
					<h3 style="color:#0616BC;">We are Beside you</h3>
					<p class="text-justify">The proposed software product is the Easy Doctor patient Portal (EDPP). The system will be used in any hospital, clinic, dispensary or pathology labs. Clinic or pathology to get the information from the patients and then storing that data for future usages. The Efficient Doctor Patient Portal(EDPP) is designed for Any Hospital to replace their existing manual system. Requirement statements in these documents are both functional and non-functional.We are developing the portal which is beneficial to the patients as well as to the doctors and Administrator . This portal particularly enables patients to Access their medical records, plan the appointments, schedule to doctor Appointment, pay the bills, refill prescription, appointment to test and it also helps the doctors to keep track of the patient’s medical history</p>
				</article>
			</div>
		</div>


		<div class="col-md-12">
			<div class="col-md-6">
				<article>
					<h3 style="color:#0616BC;">Fast 24 hour health service</h3>
					<p class="text-justify">We are developing the portal which is beneficial to the patients as well as to the doctors and Administrator . This portal particularly enables patients to Access their medical records, plan the appointments, schedule to doctor Appointment, pay the bills, refill prescription, appointment to test and it also helps the doctors to keep track of the patient’s medical history.By providing these features as well as easy access to online resources, portal provides much more improving management of illness. The main feature that makes any Doctor-patient portal reliable is the ability to expose individual patient health information in an efficient manner through internet. All doctor-patient portals allow patients to
interact in some way or the other with health care providers  or doctors. Administrator can check monthly transaction and can add or delete something.
</p>
				</article>
			</div>
			<div class="col-md-6">
				<img src="img/aboutimag11.jpg" alt="" class="img-responsive"><br>
			</div>
		</div>
          
    </div>
		
	
	
	

	
 <?php include('footer.php'); ?>


	
	</div><!--  containerFluid Ends -->




	<script src="js/bootstrap.min.js"></script>





	
</body>
</html>