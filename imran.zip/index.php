<?php include('header.php'); ?>


	<!-- this is for welcome -->
	<div class="content">
		<article>
			<p style="margin-left: 45%"><img src="img/welcome1.png" alt="welcome msg" ></p>
			<p class="text-justify">The Easy Doctor-patient portals are healthcare-related online portal that allow patients to interrelate and communicate with doctor .The EDPP provides the benefits of enhanced administration & control, superior patient care, strict cost control and improved profitability .The Easy Doctor Patient portal system is  powerful, flexible, and easy to use and is designed and developed to deliver real inferable benefits to hospitals. More importantly it is backed by reliable and dependable support. 
The project ‘Easy Doctor Patient Portal ’ is based on the database, php ,object oriented and networking techniques. 

			</p>
		</article>


	
	</div><br>

	<!-- nivo slider starts -->
	<div class="col-md-12 sliderImg">
		<img src="img/d1.jpg" alt="">
		<img src="img/d3.jpg" alt="">
		<img src="img/d2.jpg" alt="">
		<img src="img/doctor01.jpg"   alt="">
		
		
	</div>
	<!-- nivo slider ends -->

	<!-- main Content -->
	<div class="main_content">
		<div class="col-md-8">
			<article>
			<h3 style="font-weight: bold;font-family:inherit;">Finds Doctors from anywhere anytime!</h3><hr>
				<p class="text-justify">Blood is universally recognized as the most precious element that sustains life. It saves innumerable lives across the world in a variety of conditions. The need for blood is great - on any given day, approximately 39,000 units of Red Blood Cells are needed. More than 29 million units of blood components are transfused every year. Donate Blood Despite the increase in the number of donors, blood remains in short supply during emergencies, mainly attributed to the lack of information and accessibility. We positively believe this tool can overcome most of these challenges by effectively connecting the blood donors with the blood recipients.

.</p>
			</article>
		</div>
		<div class="col-md-4">
			<h3 class="text-center" style="font-weight:bold;font-family:inherit;">Doctors Appoinment...?</h3><hr>
			<ul class="text-justify">
				
				Since Hospital is related with the lives of common people and their day-to-day routines so we decided to work on this project. The manual handling of the record is time consuming and highly prone to error. The purpose of this  project is to automate or make online, the process of day-to-day activities like Appointment New Patient, Admission of New Patient, Discharge of Patient, Assign a Doctor, Scheduling Doctor and finally compute the bill through Online etc.
			</ul>
		</div>

          
    </div>


    <div class="content">
		<article>
			<p style="margin-left: 400px;"><img src="img/covid.jpg" alt="welcome msg" style="width:50%;height:100px;"></p>
			<marquee width="100%" direction="left" height="100px" behavior="scroll"  scrollamount="1" color="red">
<h1>The coronavirus pandemic continues to be on the top of the global agenda, with its fighting aspect, its effects on social and economic life, and the with the debates and expectations on the disruptive transformation it will cause in the short-, medium- and long-term once the outbreak is brought under control.</h1>
</marquee>
			<p class="text-justify">
				<h4>Coronavirus disease (COVID-19) is an infectious disease caused by a newly discovered coronavirus.Most people who fall sick with COVID-19 will experience mild to moderate symptoms and recover without special treatment.Coronaviruses are a group of related RNA viruses that cause diseases in mammals and birds. In humans and birds, they cause respiratory tract infections that can range from mild to lethal. Mild illnesses in humans include some cases of the common cold (which is also caused by other viruses, predominantly rhinoviruses), while more lethal varieties can cause SARS, MERS, and COVID-19. In cows and pigs they cause diarrhea, while in mice they cause hepatitis and encephalomyelitis.

Coronaviruses constitute the subfamily Orthocoronavirinae, in the family Coronaviridae, order Nidovirales, and realm Riboviria.[5][4] They are enveloped viruses with a positive-sense single-stranded RNA genome and a nucleocapsid of helical symmetry.[6] The genome size of coronaviruses ranges from approximately 26 to 32 kilobases, one of the largest among RNA viruses.[7] They have characteristic club-shaped spikes that project from their surface, which in electron micrographs create an image reminiscent of the solar corona, from which their name derives<h4>


			</p>
		</article>


	
	</div><br>

	<!-- nivo slider starts -->
	<div class="col-md-12 sliderImg1">
		
		<img src="img/covid2.jpg" alt="">
		<img src="img/covid3.jpg" alt="">
		<img src="img/covid4.jpg"   alt="">
		<img src="img/covid5.jpg"   alt="">
		
		
	</div>
	<!-- nivo slider ends -->

	<!-- main Content -->
	<div class="main_content">
		<div class="col-md-6">
			<article>
			<h3 style="font-weight: bold;font-family:inherit;">HOW IT SPREADS</h3><hr>
				<p class="text-justify">The virus that causes COVID-19 is mainly transmitted through droplets generated when an infected person coughs, sneezes, or exhales. These droplets are too heavy to hang in the air, and quickly fall on floors or surfaces.
You can be infected by breathing in the virus if you are within close proximity of someone who has COVID-19, or by touching a contaminated surface and then your eyes, nose or mouth.
Coronaviruses constitute the subfamily Orthocoronavirinae, in the family Coronaviridae, order Nidovirales, and realm Riboviria.[5][4] They are enveloped viruses with a positive-sense single-stranded RNA genome and a nucleocapsid of helical symmetry.[6] The genome size of coronaviruses ranges from approximately 26 to 32 kilobases, one of the largest among RNA viruses.[7] They have characteristic club-shaped spikes that project from their surface, which in electron micrographs create an image reminiscent of the solar corona, from which their name derives
Current evidence suggests that COVID-19 spreads between people through direct, indirect (through contaminated objects or surfaces), or close contact with infected people via mouth and nose secretions. These include saliva, respiratory secretions or secretion droplets. These are released from the mouth or nose when an infected person coughs, sneezes, speaks or sings, for example. People who are in close contact (within 1 metre) with an infected person can catch COVID-19 when those infectious droplets get into their mouth, nose or eyes.

To avoid contact with these droplets, it is important to stay at least 1 metre away from others, clean hands frequently, and cover the mouth with a tissue or bent elbow when sneezing or coughing. When physical distancing (standing one metre or more away) is not possible, wearing a fabric mask is an important measure to protect others. Cleaning hands frequently is also critical.

.</p>
			</article>
		</div>
		<div class="col-md-6">
			<h3 class="text-center" style="font-weight:bold;font-family:inherit;">Health Information</h3><hr>
			<ul class="text-justify">
				
				COVID-19 affects different people in different ways. Most infected people will develop mild to moderate illness and recover without hospitalization.
				<pre>
		Most common symptoms:
***fever
***dry cough
***tiredness
Less common symptoms:
**aches and pains
**sore throat
**diarrhoea
**conjunctivitis
**headache
**loss of taste or smell
a rash on skin, or discolouration of fingers or toes
</pre>
			</ul>
		</div>

          
    </div>

   
 	


   
 	<?php include('footer.php'); ?>


	
</div>	<!--  containerFluid Ends -->



	<script src="js/jquery-1.9.0.min.js"></script>
	<script src="js/bootstrap.min.js"></script>

	 
	
</body>
</html>